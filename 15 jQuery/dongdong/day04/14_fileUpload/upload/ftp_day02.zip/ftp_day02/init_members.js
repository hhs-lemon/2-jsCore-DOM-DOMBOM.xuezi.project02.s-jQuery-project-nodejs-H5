db.members.drop();
db.members.insert([
  {user:"tom",favorites:["游泳","打牌"]},
  {user:"jerry",favorites:["游泳","打牌","上网"]},
  {user:"jack",favorites:["游泳","打牌","上网"]},
  {user:"rose",favorites:["骑马","打牌","上网","跑步"]},
  {user:"smith",favorites:["游泳","打牌","上网"]},
]);