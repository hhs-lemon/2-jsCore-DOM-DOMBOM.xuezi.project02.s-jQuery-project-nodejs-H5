db.users.drop();
db.users.insert([
 {name:"tom",address:{city:"北京",street:"万寿路"}},
 {name:"jerry",address:{city:"北京",street:"知春路"}},
 {name:"smith",address:{city:"上海",street:"陕西路"}},
 {name:"john",address:{city:"重庆",street:"朝天门",no:"6号"}},
]);