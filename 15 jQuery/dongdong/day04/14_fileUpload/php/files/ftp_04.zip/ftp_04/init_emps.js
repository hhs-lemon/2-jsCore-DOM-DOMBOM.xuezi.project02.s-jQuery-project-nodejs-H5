db.emps.drop();
for(var i=0,arr=[];i<100;i++){
    arr.push({
        ename:"e"+(100+i+"").slice(1),
        address:{
            city:"city"+(10+parseInt(Math.random()*10)+"").slice(1),
            street:"street"+(100+parseInt(Math.random()*100)+"").slice(1)
	}
    });
}
db.emps.insert(arr);




